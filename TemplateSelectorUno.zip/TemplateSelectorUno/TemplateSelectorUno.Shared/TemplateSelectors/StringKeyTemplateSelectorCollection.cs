﻿using System.Collections.Generic;

namespace TemplateSelectorUno.Shared.Common.TemplateSelectors
{
    public class StringKeyTemplateSelectorCollection : List<StringTemplateSelectorItem>
    {
    }
}